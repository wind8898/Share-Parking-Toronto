// API key
const API_KEY = "pk.eyJ1IjoiamFybW91cjQxNiIsImEiOiJjazV4NDhhNzQyMjVnM2Vubjk1dXE5aXRsIn0.ylj25jbbMKrNYQheMToLvA";